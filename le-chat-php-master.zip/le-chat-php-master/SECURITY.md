# Security Policy

I take sucurity very seriously and anyone is welcome to report vulnerabiliteis found. Please get in touch with me by email on [daniel@danwin1210.de](mailto:daniel@danwin1210.de) if you have found a vulnerability. For non-critical issues and suggestions, feel free to open a new Issue.
